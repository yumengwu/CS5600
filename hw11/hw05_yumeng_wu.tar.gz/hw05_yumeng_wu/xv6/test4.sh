echo line1
echo line2
false && echo fail
