#ifndef __DATE__H
#define __DATE__H
struct rtcdate {
  uint second;
  uint minute;
  uint hour;
  uint day;
  uint month;
  uint year;
};
#endif