#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int sys_exit1(void)
{
  int status;
  argint(0, &status);
  exit1(status);
  return 0;
}

int sys_wait1(void)
{
  int * status;
  argptr(0, (void*)&status, sizeof(status));
  return wait1(status);
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// add sys_halt
int
sys_halt()
{
  outw(0x604, 0x2000);
  return 0;
}

int sys_spalloc()
{
  return (int) (spalloc());
}

int sys_spfree()
{
  int ptr;
  if (argint(0, &ptr) < 0)
  {
    return -1;
  }
  return spfree(ptr);
}

int sys_mutex_init()
{
  int i;
  if (argint(0, &i) < 0)
    return -1;
  mutex_t * m = (mutex_t *) i;
  if (!m)
    return -1;
  return mutex_init(m);
}

int sys_mutex_lock()
{
  int i;
  if (argint(0, &i) < 0)
    return -1;
  mutex_t * m = (mutex_t *) i;
  if (!m)
    return -1;
  return mutex_lock(m);
}

int sys_mutex_unlock()
{
  int i;
  if (argint(0, &i) < 0)
    return -1;
  mutex_t * m = (mutex_t *) i;
  if (!m)
    return -1;
  return mutex_unlock(m);
}
