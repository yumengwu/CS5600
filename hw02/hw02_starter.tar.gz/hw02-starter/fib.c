
#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char* argv[])
{
    long xx = atol(argv[1]);
    printf("fib(3) = %ld\n", xx);
    return 0;
}

