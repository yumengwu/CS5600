// Author: Nat Tuck
// CS3650 starter code

#ifndef UTILS_H
#define UTILS_H

void seed_rng();
void check_rv(int rv);

#endif

