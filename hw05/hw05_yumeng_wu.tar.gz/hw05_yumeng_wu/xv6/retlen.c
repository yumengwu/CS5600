#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char* argv[])
{
  int len = strlen(argv[1]);
  return len;
}
