#ifndef STR_H
#define STR_H

long  len(char* xx);
char* rev(char* xx);
long  aton(char* xx);
char* ntoa(long xx);
char* dup(char* xx);

#endif
