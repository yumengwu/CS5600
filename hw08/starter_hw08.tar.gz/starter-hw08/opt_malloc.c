
#include "xmalloc.h"

void*
xmalloc(size_t bytes)
{
    // TODO: write an optimized malloc
    return 0;
}

void
xfree(void* ptr)
{
    // TODO: write an optimized free
}

void*
xrealloc(void* prev, size_t bytes)
{
    // TODO: write an optimized realloc
    return 0;
}
